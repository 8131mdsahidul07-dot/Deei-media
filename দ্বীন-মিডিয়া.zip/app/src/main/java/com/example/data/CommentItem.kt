package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comments")
data class CommentItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long,
    val userName: String,
    val userAvatar: String? = null,
    val commentText: String,
    val timestamp: Long = System.currentTimeMillis()
)
