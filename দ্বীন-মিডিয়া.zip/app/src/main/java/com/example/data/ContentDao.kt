package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ContentDao {
    @Query("SELECT * FROM content_items WHERE moderationStatus = 'APPROVED' ORDER BY timestamp DESC")
    fun getApprovedContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE type = 'VIDEO' AND moderationStatus = 'APPROVED' ORDER BY timestamp DESC")
    fun getApprovedVideos(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE type != 'VIDEO' AND moderationStatus = 'APPROVED' ORDER BY timestamp DESC")
    fun getApprovedPosts(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE isUserCreated = 1 ORDER BY timestamp DESC")
    fun getUserUploads(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE moderationStatus = 'PENDING_REVIEW' ORDER BY timestamp DESC")
    fun getPendingReviews(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE isBookmarked = 1 ORDER BY timestamp DESC")
    fun getBookmarkedContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE id = :id")
    suspend fun getContentById(id: Long): ContentItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContent(item: ContentItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ContentItem>)

    @Update
    suspend fun updateContent(item: ContentItem)

    @Query("UPDATE content_items SET isLiked = :isLiked, likesCount = likesCount + :delta WHERE id = :id")
    suspend fun toggleLike(id: Long, isLiked: Boolean, delta: Int)

    @Query("UPDATE content_items SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: Long, isBookmarked: Boolean)

    @Query("UPDATE content_items SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: Long)

    @Query("UPDATE content_items SET moderationStatus = :status, moderationNotes = :notes WHERE id = :id")
    suspend fun updateModerationStatus(id: Long, status: ModerationStatus, notes: String?)

    @Query("UPDATE content_items SET reportCount = reportCount + 1 WHERE id = :id")
    suspend fun incrementReportCount(id: Long)

    @Query("SELECT COUNT(*) FROM content_items")
    suspend fun getContentCount(): Int

    // Comments
    @Query("SELECT * FROM comments WHERE contentId = :contentId ORDER BY timestamp DESC")
    fun getCommentsForContent(contentId: Long): Flow<List<CommentItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentItem): Long

    // Reports
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportItem): Long

    @Query("SELECT * FROM reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<ReportItem>>
}
