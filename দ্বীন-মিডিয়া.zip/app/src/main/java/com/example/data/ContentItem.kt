package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ContentType {
    VIDEO,
    POST,
    AYAT,
    HADITH,
    DUA,
    QUOTE
}

enum class ModerationStatus {
    APPROVED,
    PENDING_REVIEW,
    REJECTED
}

@Entity(tableName = "content_items")
data class ContentItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val arabicText: String? = null,
    val description: String,
    val type: ContentType,
    val category: String, // "কুরআন", "হাদিস", "দোয়া", "ওয়াজ", "তিলাওয়াত", "শিশুদের ইসলাম", "ইসলামিক ইতিহাস"
    val sourceReference: String, // e.g. "সহীহ বুখারী, হাদিস নং ১", "সূরা আল-বাকারা, আয়াত ২৫৫"
    val authorName: String,
    val authorRole: String = "ইসলামিক বক্তা / আলোচক",
    val authorAvatar: String? = null,
    val mediaUrl: String? = null,
    val duration: String? = null, // e.g. "12:45"
    val viewsCount: Int = 0,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val isBookmarked: Boolean = false,
    val isFollowed: Boolean = false,
    val moderationStatus: ModerationStatus = ModerationStatus.APPROVED,
    val moderationNotes: String? = null,
    val reportCount: Int = 0,
    val isUserCreated: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
