package com.example.data

import kotlinx.coroutines.flow.Flow

class ContentRepository(private val dao: ContentDao) {

    val approvedContent: Flow<List<ContentItem>> = dao.getApprovedContent()
    val approvedVideos: Flow<List<ContentItem>> = dao.getApprovedVideos()
    val approvedPosts: Flow<List<ContentItem>> = dao.getApprovedPosts()
    val userUploads: Flow<List<ContentItem>> = dao.getUserUploads()
    val pendingReviews: Flow<List<ContentItem>> = dao.getPendingReviews()
    val bookmarkedContent: Flow<List<ContentItem>> = dao.getBookmarkedContent()
    val allReports: Flow<List<ReportItem>> = dao.getAllReports()

    suspend fun checkAndPrepopulate() {
        val count = dao.getContentCount()
        if (count == 0) {
            dao.insertAll(InitialData.getInitialContent())
            InitialData.getInitialComments().forEach {
                dao.insertComment(it)
            }
        }
    }

    suspend fun toggleLike(item: ContentItem) {
        val newLiked = !item.isLiked
        val delta = if (newLiked) 1 else -1
        dao.toggleLike(item.id, newLiked, delta)
    }

    suspend fun toggleBookmark(item: ContentItem) {
        dao.toggleBookmark(item.id, !item.isBookmarked)
    }

    suspend fun incrementViews(id: Long) {
        dao.incrementViews(id)
    }

    suspend fun uploadContent(
        title: String,
        arabicText: String?,
        description: String,
        type: ContentType,
        category: String,
        sourceReference: String,
        authorName: String,
        duration: String? = null
    ): Long {
        val newItem = ContentItem(
            title = title,
            arabicText = arabicText?.takeIf { it.isNotBlank() },
            description = description,
            type = type,
            category = category,
            sourceReference = sourceReference,
            authorName = authorName.ifBlank { "ব্যবহারকারী ক্রিয়েটর" },
            authorRole = "নূর কন্টেন্ট ক্রিয়েটর",
            duration = duration,
            moderationStatus = ModerationStatus.PENDING_REVIEW, // Safe moderation rule!
            moderationNotes = "ইসলামিক তাহকীক বোর্ডের কাছে পর্যালোচনার জন্য জমা দেওয়া হয়েছে।",
            isUserCreated = true
        )
        return dao.insertContent(newItem)
    }

    suspend fun moderateItem(id: Long, status: ModerationStatus, notes: String?) {
        dao.updateModerationStatus(id, status, notes)
    }

    suspend fun reportContent(
        contentId: Long,
        contentTitle: String,
        reason: String,
        details: String
    ) {
        val report = ReportItem(
            contentId = contentId,
            contentTitle = contentTitle,
            reason = reason,
            details = details
        )
        dao.insertReport(report)
        dao.incrementReportCount(contentId)
    }

    fun getComments(contentId: Long): Flow<List<CommentItem>> {
        return dao.getCommentsForContent(contentId)
    }

    suspend fun addComment(contentId: Long, userName: String, text: String) {
        val comment = CommentItem(
            contentId = contentId,
            userName = userName.ifBlank { "মুমিন পাঠক" },
            commentText = text
        )
        dao.insertComment(comment)
    }
}
