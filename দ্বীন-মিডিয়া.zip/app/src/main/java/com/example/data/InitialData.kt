package com.example.data

object InitialData {
    fun getInitialContent(): List<ContentItem> {
        val now = System.currentTimeMillis()
        return listOf(
            // 1. Featured Video - Tilawat
            ContentItem(
                id = 1,
                title = "সূরা আর-রহমান হৃদয়স্পর্শী তিলাওয়াত | Surah Ar-Rahman",
                arabicText = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ",
                description = "মক্কার পবিত্র মসজিদুল হারামের ইমাম মিশারি রাশিদ আলাফাসির সুললিত কণ্ঠে সূরা আর-রহমানের পূর্ণাঙ্গ তিলাওয়াত ও বাংলা অনুবাদ।",
                type = ContentType.VIDEO,
                category = "তিলাওয়াত",
                sourceReference = "পবিত্র কুরআন, সূরা আর-রহমান (৫৫)",
                authorName = "ক্বারী মিশারি রাশিদ আলাফাসি",
                authorRole = "আন্তর্জাতিক কুরআন তিলাওয়াতকারী",
                duration = "14:22",
                viewsCount = 124800,
                likesCount = 8920,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 2
            ),

            // 2. Video - Waz / Bayan
            ContentItem(
                id = 2,
                title = "জীবনের কঠিন সময়ে কীভাবে সবর ও মানসিক শান্তি পাবেন",
                arabicText = "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
                description = "জীবনের পরীক্ষা, সংকট ও একাকিত্বে মুমিনের করণীয় এবং আল্লাহ তাআলার রহমতের উপর অগাধ বিশ্বাস স্থাপনের বাস্তবসম্মত আলোচনা।",
                type = ContentType.VIDEO,
                category = "ওয়াজ",
                sourceReference = "সূরা আল-বাকারা: ১৫৩ ও সহীহ মুসলিম",
                authorName = "মাওলানা মিজানুর রহমান আজহারী",
                authorRole = "বিশিষ্ট ইসলামিক স্কলার ও গবেষক",
                duration = "22:15",
                viewsCount = 87400,
                likesCount = 6430,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 5
            ),

            // 3. Post - Ayat
            ContentItem(
                id = 3,
                title = "আল্লাহ কোনো আত্মাকে তার সাধ্যের অতিরিক্ত বোঝা চাপিয়ে দেন না",
                arabicText = "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
                description = "হে মুমিনগণ, ধৈর্য ধরুন! আপনার প্রতিটি কষ্টের প্রতিদান আল্লাহর কাছে সংরক্ষিত রয়েছে। তিনি জানেন আপনার সহ্যশক্তি কতটুকু।",
                type = ContentType.AYAT,
                category = "কুরআন",
                sourceReference = "সূরা আল-বাকারা (২:২৮৬)",
                authorName = "নূর মিডিয়া তাহকীক বোর্ড",
                authorRole = "ভেরিফায়েড ইসলামিক কন্টেন্ট",
                likesCount = 4210,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 7
            ),

            // 4. Video - Hadith Learning
            ContentItem(
                id = 4,
                title = "সব কাজের ফলাফল নিয়তের উপর নির্ভরশীল | হাদিস শিক্ষা",
                arabicText = "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ",
                description = "সহীহ বুখারীর সর্বপ্রথম হাদিসের পূর্ণ ব্যাখ্যা। কেন জীবনের প্রতিটি ভালো কাজকে ইবাদতে রূপান্তর করতে বিশুদ্ধ নিয়ত প্রয়োজন?",
                type = ContentType.VIDEO,
                category = "হাদিস",
                sourceReference = "সহীহুল বুখারী, হাদিস নং ১",
                authorName = "ড. আব্দুল্লাহ জাহাঙ্গীর (রহ.)",
                authorRole = "প্রখ্যাত হাদিস বিশারদ",
                duration = "10:48",
                viewsCount = 53200,
                likesCount = 4820,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 12
            ),

            // 5. Post - Dua
            ContentItem(
                id = 5,
                title = "ঋণমুক্তি ও দুশ্চিন্তা দূর করার বিশেষ মাসনূন দোয়া",
                arabicText = "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْجُبْنِ وَالْبُخْلِ، وَضَلَعِ الدَّيْنِ، وَغَلَبَةِ الرِّجَالِ",
                description = "উচ্চারণ: 'আল্লাহুম্মা ইন্নি আউজু বিকা মিনাল হাম্মি ওয়াল হাযানি, ওয়াল আজযি ওয়াল কাসালি, ওয়াল জুবনি ওয়াল বুখলি, ওয়া দ্বলা'ইদ দাইনি ওয়া গালাবাতির রিজাল।'\n\nঅর্থ: 'হে আল্লাহ! নিশ্চয়ই আমি আপনার আশ্রয় নিচ্ছি চিন্তা-ভাবনা ও পেরেশানি থেকে, অক্ষমতা ও অলসতা থেকে, ভীরুতা ও কৃপণতা থেকে এবং ঋণের বোঝা ও মানুষের আধিপত্য থেকে।' (সকাল-সন্ধ্যায় পড়ার তাগিদ)",
                type = ContentType.DUA,
                category = "দোয়া",
                sourceReference = "সহীহ বুখারী: ২৮৯৩ (হিসনুল মুসলিম)",
                authorName = "নূর মিডিয়া তাহকীক বোর্ড",
                authorRole = "ভেরিফায়েড ইসলামিক কন্টেন্ট",
                likesCount = 9810,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 18
            ),

            // 6. Video - Kids Islam
            ContentItem(
                id = 6,
                title = "হযরত ইউনুস (আ.) ও মাছের পেটের সত্য ঘটনা | শিশুদের ইসলামিক গল্প",
                arabicText = "لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ",
                description = "ছোটদের সহজে বোঝার জন্য মনোরম অ্যানিমেশন ও সহজ ভাষায় বর্ণিত নবী ইউনুস (আ.)-এর দোয়ার শক্তি ও ক্ষমার শিক্ষণীয় কাহিনী।",
                type = ContentType.VIDEO,
                category = "শিশুদের ইসলাম",
                sourceReference = "পবিত্র কুরআন, সূরা আল-আম্বিয়া: ৮৭-৮৮",
                authorName = "নূর চিলড্রেনস উইং",
                authorRole = "শিশু-কিশোর ইসলামিক একাডেমি",
                duration = "08:35",
                viewsCount = 39800,
                likesCount = 2750,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 24
            ),

            // 7. Post - Islamic History
            ContentItem(
                id = 7,
                title = "বদর যুদ্ধ: সত্য ও মিথ্যার প্রথম চূড়ান্ত ঐতিহাসিক সংগ্রাম",
                arabicText = "وَلَقَدْ نَصَرَكُمُ اللَّهُ بِبَدْرٍ وَأَنتُمْ أَذِلَّةٌ",
                description = "১৭ই রমজান সংঘটিত ইসলামের প্রথম সশস্ত্র প্রতিরোধ। কীভাবে মাত্র ৩১৩ জন নিরস্ত্র মুসলিম তৎকালীন আরবের সুসজ্জিত কুরাইশ বাহিনীকে প্রতিহত করেছিলেন—তার নির্ভরযোগ্য ইতিহাস ও রণনীতি বিশ্লেষণ।",
                type = ContentType.POST,
                category = "ইসলামিক ইতিহাস",
                sourceReference = "সূরা আল-ইমরান: ১২৩ ও আর-রাহীকুল মাখতূম",
                authorName = "ড. খন্দকার আব্দুল্লাহ",
                authorRole = "ইতিহাস গবেষক",
                likesCount = 3450,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 30
            ),

            // 8. Video - Nasheed
            ContentItem(
                id = 8,
                title = "তাওহীদের আলোকবর্তিকা | বাদ্যযন্ত্রহীন সুমধুর ইসলামিক নাশিদ",
                arabicText = "لَا إِلٰهَ إِلَّا اللهُ مُحَمَّدٌ رَّسُولُ اللهِ",
                description = "মনকে প্রশান্তি দেওয়ার মতো চমৎকার সুর ও তাওহীদের মাহাত্ম্য নিয়ে তৈরি সম্পূর্ণ হালাল সাউন্ডের ইসলামিক নাশিদ।",
                type = ContentType.VIDEO,
                category = "ওয়াজ",
                sourceReference = "সহীহ বর্ণনা ভিত্তিক ভাবানুবাদ",
                authorName = "মুহাম্মদ আল-মুকাদ্দাস",
                authorRole = "আন্তর্জাতিক নাশিদ শিল্পী",
                duration = "05:12",
                viewsCount = 67200,
                likesCount = 5120,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 36
            ),

            // 9. Post - Islamic Quote
            ContentItem(
                id = 9,
                title = "উমর ইবনুল খাত্তাব (রা.)-এর ঐতিহাসিক প্রজ্ঞাময় উপদেশ",
                arabicText = "حَاسِبُوا أَنْفُسَكُمْ قَبْلَ أَنْ تُحَاسَبُوا",
                description = "হযরত উমর (রা.) বলেছেন: 'তোমাদের হিসাব নেওয়ার পূর্বেই তোমরা নিজেদের হিসাব গ্রহণ করো এবং তোমাদের কাজের ওজন করার পূর্বেই তা পরিমাপ করো। কারণ আজকের দিনে নিজের হিসাব নেওয়া আগামীকালের চরম হিসাবকে অনেক সহজ করে দেবে।'\n\nআত্মশুদ্ধির সেরা পাথেয়।",
                type = ContentType.QUOTE,
                category = "হাদিস",
                sourceReference = "হিলয়াতুল আওলিয়া ও সুনানে তিরমিযী (২৪৫৯)",
                authorName = "নূর মিডিয়া তাহকীক বোর্ড",
                authorRole = "ভেরিফায়েড ইসলামিক কন্টেন্ট",
                likesCount = 7650,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 42
            ),

            // 10. Post - Ramadan / Eid
            ContentItem(
                id = 10,
                title = "রমজানের শেষ দশকে লাইলাতুল কদরের বিশেষ দোয়া",
                arabicText = "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي",
                description = "উম্মুল মুমিনীন আয়েশা (রা.) রাসূলুল্লাহ ﷺ-কে জিজ্ঞেস করলেন, হে আল্লাহর রাসূল, আমি যদি বুঝতে পারি কদরের রাত কোনটি, তবে কী বলব? রাসূলুল্লাহ ﷺ এই দোয়াটি শিক্ষা দিলেন।\n\nঅর্থ: 'হে আল্লাহ! নিশ্চয়ই আপনি ক্ষমাশীল, আপনি ক্ষমা করতে ভালোবাসেন। অতএব আমাকে ক্ষমা করুন।'",
                type = ContentType.DUA,
                category = "দোয়া",
                sourceReference = "জামে আত-তিরমিযী: ৩৫১৩ (সহীহ)",
                authorName = "হাফেজ মাওলানা জুবায়ের আহমদ",
                authorRole = "খতিব ও মুহাদ্দিস",
                likesCount = 11200,
                moderationStatus = ModerationStatus.APPROVED,
                timestamp = now - 3600000 * 48
            ),

            // 11. Pending Review User Item (Creator System demo)
            ContentItem(
                id = 11,
                title = "মা-বাবার প্রতি সন্তানের ৭টি দায়িত্ব ও কুরআন-সুন্নাহর নির্দেশনা",
                arabicText = "وَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا",
                description = "কুরআন ও হাদিসের আলোকে বৃদ্ধ বয়সে পিতা-মাতার সন্তুষ্টি অর্জন ও তাদের সাথে সদ্ব্যবহারের বাস্তবিক উপায় নিয়ে একটি বিস্তারিত আলোচনা নোট।",
                type = ContentType.POST,
                category = "কুরআন",
                sourceReference = "সূরা বনি ইসরাঈল: ২৩-২৪",
                authorName = "মোঃ সাহিদুল ইসলাম (ক্রিয়েটর)",
                authorRole = "কন্টেন্ট ক্রিয়েটর",
                moderationStatus = ModerationStatus.PENDING_REVIEW,
                moderationNotes = "তাহকীক বোর্ড দ্বারা তথ্য ও রেফারেন্স যাচাই চলছে। অনুমোদন পেলে পাবলিক ফিডে প্রদর্শিত হবে।",
                isUserCreated = true,
                timestamp = now - 1800000
            )
        )
    }

    fun getInitialComments(): List<CommentItem> {
        val now = System.currentTimeMillis()
        return listOf(
            CommentItem(
                id = 1,
                contentId = 1,
                userName = "মুহাম্মদ আবদুল্লাহ",
                commentText = "মাশাআল্লাহ! সূরা আর-রহমানের তিলাওয়াত শুনলে অন্তরে প্রশান্তি অনুভূত হয়। জাযাকাল্লাহু খাইরান নূর মিডিয়া।",
                timestamp = now - 1800000
            ),
            CommentItem(
                id = 2,
                contentId = 1,
                userName = "ফাতিমা তুয যোহরা",
                commentText = "এমন নিরাপদ এবং খাঁটি ইসলামিক অ্যাপ আমাদের পরিবারে প্রতিদিনের প্রয়োজন ছিল। আল্লাহ এর উদ্যোগকে কবুল করুন।",
                timestamp = now - 900000
            ),
            CommentItem(
                id = 3,
                contentId = 5,
                userName = "আব্দুর রহমান",
                commentText = "এই দোয়াটি প্রতিদিন ফজরের পর পাঠ করি। এর উপকারিতা সত্যিই অতুলনীয়।",
                timestamp = now - 1200000
            )
        )
    }
}
