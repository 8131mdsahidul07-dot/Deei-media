package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reports")
data class ReportItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentId: Long,
    val contentTitle: String,
    val reason: String,
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "পর্যালোচনাধীন" // "পর্যালোচনাধীন", "সমাধানকৃত"
)
