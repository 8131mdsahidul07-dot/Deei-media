package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.AddBox
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CommentsSheet
import com.example.ui.components.ReportDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DownloadScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MonetizationScreen
import com.example.ui.screens.PostsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.UploadScreen
import com.example.ui.screens.VideosScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoorApp(
    viewModel: NoorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val approvedContent by viewModel.approvedContent.collectAsStateWithLifecycle()
    val approvedVideos by viewModel.approvedVideos.collectAsStateWithLifecycle()
    val approvedPosts by viewModel.approvedPosts.collectAsStateWithLifecycle()
    val userUploads by viewModel.userUploads.collectAsStateWithLifecycle()
    val pendingReviews by viewModel.pendingReviews.collectAsStateWithLifecycle()
    val bookmarkedContent by viewModel.bookmarkedContent.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var isSearchOpen by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Full screen Splash Screen on launch or when replayed
    if (uiState.isSplashVisible) {
        SplashScreen(
            onDismissSplash = { viewModel.dismissSplash() }
        )
        return
    }

    // Full screen Auth (Login / Register) Screen with Deen Media Branding
    if (uiState.showAuthDialog) {
        AuthScreen(
            initialTab = uiState.authInitialTab,
            onClose = { viewModel.closeAuth() },
            onAuthSuccess = { userName, isNew ->
                viewModel.onAuthSuccess(userName, isNew)
            }
        )
        return
    }

    // Full screen Monetization Hub if requested
    if (uiState.showMonetizationHub) {
        MonetizationScreen(
            onBack = { viewModel.toggleMonetizationHub(false) },
            onShowMessage = { viewModel.showSnackbar(it) }
        )
        return
    }

    // Full screen App Download Section
    if (uiState.showDownloadSection) {
        DownloadScreen(
            onClose = { viewModel.closeDownloadSection() }
        )
        return
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Column {
                // Mini Player Bar when a video is active and not on Videos tab
                if (uiState.activePlayingVideo != null && uiState.currentTab != NoorNavTab.VIDEOS) {
                    val activeVid = uiState.activePlayingVideo!!
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectTab(NoorNavTab.VIDEOS) }
                            .testTag("mini_player_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(EmeraldPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = activeVid.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = activeVid.authorName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { viewModel.togglePlayPause() }) {
                                    Icon(
                                        imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Toggle play"
                                    )
                                }
                                IconButton(onClick = { viewModel.closeVideoPlayer() }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close player"
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Navigation Bar
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = (uiState.currentTab == NoorNavTab.HOME && !isSearchOpen),
                        onClick = {
                            isSearchOpen = false
                            viewModel.selectTab(NoorNavTab.HOME)
                        },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == NoorNavTab.HOME && !isSearchOpen) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "হোম"
                            )
                        },
                        label = { Text("হোম") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = (uiState.currentTab == NoorNavTab.VIDEOS && !isSearchOpen),
                        onClick = {
                            isSearchOpen = false
                            viewModel.selectTab(NoorNavTab.VIDEOS)
                        },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == NoorNavTab.VIDEOS && !isSearchOpen) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                                contentDescription = "ভিডিও"
                            )
                        },
                        label = { Text("ভিডিও") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_videos")
                    )

                    NavigationBarItem(
                        selected = (uiState.currentTab == NoorNavTab.POSTS && !isSearchOpen),
                        onClick = {
                            isSearchOpen = false
                            viewModel.selectTab(NoorNavTab.POSTS)
                        },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == NoorNavTab.POSTS && !isSearchOpen) Icons.Filled.MenuBook else Icons.Outlined.MenuBook,
                                contentDescription = "পোস্ট"
                            )
                        },
                        label = { Text("পোস্ট") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_posts")
                    )

                    NavigationBarItem(
                        selected = (uiState.currentTab == NoorNavTab.UPLOAD && !isSearchOpen),
                        onClick = {
                            isSearchOpen = false
                            viewModel.selectTab(NoorNavTab.UPLOAD)
                        },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == NoorNavTab.UPLOAD && !isSearchOpen) Icons.Filled.AddBox else Icons.Outlined.AddBox,
                                contentDescription = "আপলোড"
                            )
                        },
                        label = { Text("আপলোড") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_upload")
                    )

                    NavigationBarItem(
                        selected = (uiState.currentTab == NoorNavTab.PROFILE && !isSearchOpen),
                        onClick = {
                            isSearchOpen = false
                            viewModel.selectTab(NoorNavTab.PROFILE)
                        },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == NoorNavTab.PROFILE && !isSearchOpen) Icons.Filled.Person else Icons.Outlined.Person,
                                contentDescription = "প্রোফাইল"
                            )
                        },
                        label = { Text("প্রোফাইল") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (isSearchOpen) {
                SearchScreen(
                    searchQuery = uiState.searchQuery,
                    onQueryChanged = { viewModel.onSearchQueryChanged(it) },
                    allContent = approvedContent,
                    onPlayVideo = {
                        viewModel.startPlayingVideo(it)
                        viewModel.selectTab(NoorNavTab.VIDEOS)
                        isSearchOpen = false
                    },
                    onToggleLike = { viewModel.toggleLike(it) },
                    onToggleBookmark = { viewModel.toggleBookmark(it) },
                    onOpenReport = { viewModel.openReportDialog(it) },
                    onCopySuccess = { viewModel.showSnackbar(it) }
                )
            } else {
                when (uiState.currentTab) {
                    NoorNavTab.HOME -> {
                        HomeScreen(
                            contentList = approvedContent,
                            selectedCategory = uiState.selectedCategory,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            onPlayVideo = {
                                viewModel.startPlayingVideo(it)
                                viewModel.selectTab(NoorNavTab.VIDEOS)
                            },
                            onToggleLike = { viewModel.toggleLike(it) },
                            onToggleBookmark = { viewModel.toggleBookmark(it) },
                            onOpenReport = { viewModel.openReportDialog(it) },
                            onCopySuccess = { viewModel.showSnackbar(it) },
                            onOpenSearch = { isSearchOpen = true },
                            onOpenDownloadSection = { viewModel.openDownloadSection() }
                        )
                    }
                    NoorNavTab.VIDEOS -> {
                        VideosScreen(
                            videos = approvedVideos,
                            activeVideo = uiState.activePlayingVideo,
                            isPlaying = uiState.isPlaying,
                            currentPosSec = uiState.currentPlaybackPositionSec,
                            totalDurationSec = uiState.totalPlaybackDurationSec,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSeek = { viewModel.seekTo(it) },
                            onClosePlayer = { viewModel.closeVideoPlayer() },
                            onPlayVideo = { viewModel.startPlayingVideo(it) },
                            onToggleLike = { viewModel.toggleLike(it) },
                            onToggleBookmark = { viewModel.toggleBookmark(it) },
                            onOpenComments = { viewModel.openComments(it) },
                            onOpenReport = { viewModel.openReportDialog(it) }
                        )
                    }
                    NoorNavTab.POSTS -> {
                        PostsScreen(
                            posts = approvedPosts,
                            onToggleLike = { viewModel.toggleLike(it) },
                            onToggleBookmark = { viewModel.toggleBookmark(it) },
                            onOpenReport = { viewModel.openReportDialog(it) },
                            onCopySuccess = { viewModel.showSnackbar(it) }
                        )
                    }
                    NoorNavTab.UPLOAD -> {
                        UploadScreen(
                            onUploadSubmitted = { title, arabic, desc, type, cat, ref, author, dur ->
                                viewModel.uploadContent(title, arabic, desc, type, cat, ref, author, dur)
                            },
                            uploadSuccessMessage = uiState.uploadSuccessMessage,
                            onDismissSuccess = {
                                viewModel.clearUploadSuccessMessage()
                                viewModel.selectTab(NoorNavTab.PROFILE)
                            }
                        )
                    }
                    NoorNavTab.PROFILE -> {
                        ProfileScreen(
                            userUploads = userUploads,
                            pendingReviews = pendingReviews,
                            bookmarkedItems = bookmarkedContent,
                            reports = reports,
                            isLoggedIn = uiState.isLoggedIn,
                            userName = uiState.loggedInUserName,
                            onOpenAuth = { tab -> viewModel.openAuth(tab) },
                            onLogout = { viewModel.logout() },
                            onViewSplash = { viewModel.showSplash() },
                            onModerateItem = { id, status, notes ->
                                viewModel.moderateContent(id, status, notes)
                            },
                            onOpenMonetizationHub = {
                                viewModel.toggleMonetizationHub(true)
                            },
                            onToggleLike = { viewModel.toggleLike(it) },
                            onToggleBookmark = { viewModel.toggleBookmark(it) },
                            onOpenReport = { viewModel.openReportDialog(it) },
                            onCopySuccess = { viewModel.showSnackbar(it) },
                            onOpenDownloadSection = { viewModel.openDownloadSection() }
                        )
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet: Comments
    if (uiState.commentsSheetItem != null) {
        CommentsSheet(
            item = uiState.commentsSheetItem!!,
            comments = activeComments,
            sheetState = sheetState,
            onDismiss = { viewModel.closeComments() },
            onAddComment = { userName, text ->
                viewModel.addComment(uiState.commentsSheetItem!!.id, userName, text)
            }
        )
    }

    // Dialog: Report
    if (uiState.reportDialogItem != null) {
        ReportDialog(
            item = uiState.reportDialogItem!!,
            onDismiss = { viewModel.closeReportDialog() },
            onSubmitReport = { id, title, reason, details ->
                viewModel.submitReport(id, title, reason, details)
            }
        )
    }
}
