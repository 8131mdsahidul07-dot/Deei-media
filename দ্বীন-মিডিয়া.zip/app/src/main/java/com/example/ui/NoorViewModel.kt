package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CommentItem
import com.example.data.ContentItem
import com.example.data.ContentType
import com.example.data.ModerationStatus
import com.example.data.NoorDatabase
import com.example.data.ContentRepository
import com.example.data.ReportItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NoorNavTab {
    HOME,
    VIDEOS,
    POSTS,
    UPLOAD,
    PROFILE
}

data class NoorUiState(
    val currentTab: NoorNavTab = NoorNavTab.HOME,
    val selectedCategory: String = "সব",
    val searchQuery: String = "",
    val activePlayingVideo: ContentItem? = null,
    val isPlaying: Boolean = true,
    val currentPlaybackPositionSec: Int = 45,
    val totalPlaybackDurationSec: Int = 862,
    val commentsSheetItem: ContentItem? = null,
    val reportDialogItem: ContentItem? = null,
    val showMonetizationHub: Boolean = false,
    val showModerationHub: Boolean = false,
    val isSplashVisible: Boolean = true,
    val showAuthDialog: Boolean = false,
    val showDownloadSection: Boolean = false,
    val authInitialTab: Int = 0,
    val isLoggedIn: Boolean = true,
    val loggedInUserName: String = "মুহাম্মাদ আবদুল্লাহ",
    val uploadSuccessMessage: String? = null,
    val snackbarMessage: String? = null
)

class NoorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ContentRepository

    private val _uiState = MutableStateFlow(NoorUiState())
    val uiState: StateFlow<NoorUiState> = _uiState.asStateFlow()

    init {
        val db = NoorDatabase.getDatabase(application)
        repository = ContentRepository(db.contentDao())
        viewModelScope.launch {
            repository.checkAndPrepopulate()
        }
    }

    val approvedContent: StateFlow<List<ContentItem>> = repository.approvedContent
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedVideos: StateFlow<List<ContentItem>> = repository.approvedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedPosts: StateFlow<List<ContentItem>> = repository.approvedPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userUploads: StateFlow<List<ContentItem>> = repository.userUploads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingReviews: StateFlow<List<ContentItem>> = repository.pendingReviews
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkedContent: StateFlow<List<ContentItem>> = repository.bookmarkedContent
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<ReportItem>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeComments = MutableStateFlow<List<CommentItem>>(emptyList())
    val activeComments: StateFlow<List<CommentItem>> = _activeComments.asStateFlow()

    fun selectTab(tab: NoorNavTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun selectCategory(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun startPlayingVideo(item: ContentItem) {
        _uiState.value = _uiState.value.copy(
            activePlayingVideo = item,
            isPlaying = true,
            currentPlaybackPositionSec = 0
        )
        viewModelScope.launch {
            repository.incrementViews(item.id)
        }
    }

    fun togglePlayPause() {
        val currentState = _uiState.value.isPlaying
        _uiState.value = _uiState.value.copy(isPlaying = !currentState)
    }

    fun seekTo(seconds: Int) {
        _uiState.value = _uiState.value.copy(currentPlaybackPositionSec = seconds)
    }

    fun closeVideoPlayer() {
        _uiState.value = _uiState.value.copy(activePlayingVideo = null)
    }

    fun toggleLike(item: ContentItem) {
        viewModelScope.launch {
            repository.toggleLike(item)
            // If the active video is the one liked, update its state too
            if (_uiState.value.activePlayingVideo?.id == item.id) {
                _uiState.value = _uiState.value.copy(
                    activePlayingVideo = _uiState.value.activePlayingVideo?.copy(
                        isLiked = !item.isLiked,
                        likesCount = if (!item.isLiked) item.likesCount + 1 else item.likesCount - 1
                    )
                )
            }
        }
    }

    fun toggleBookmark(item: ContentItem) {
        viewModelScope.launch {
            repository.toggleBookmark(item)
            showSnackbar(if (!item.isBookmarked) "সংরক্ষণ করা হয়েছে" else "সংরক্ষণ থেকে সরানো হয়েছে")
        }
    }

    fun openComments(item: ContentItem) {
        _uiState.value = _uiState.value.copy(commentsSheetItem = item)
        viewModelScope.launch {
            repository.getComments(item.id).collect { comments ->
                _activeComments.value = comments
            }
        }
    }

    fun closeComments() {
        _uiState.value = _uiState.value.copy(commentsSheetItem = null)
    }

    fun addComment(contentId: Long, userName: String, commentText: String) {
        if (commentText.isBlank()) return
        viewModelScope.launch {
            repository.addComment(contentId, userName, commentText)
            showSnackbar("আপনার মন্তব্য সফলভাবে প্রকাশিত হয়েছে।")
        }
    }

    fun openReportDialog(item: ContentItem) {
        _uiState.value = _uiState.value.copy(reportDialogItem = item)
    }

    fun closeReportDialog() {
        _uiState.value = _uiState.value.copy(reportDialogItem = null)
    }

    fun submitReport(contentId: Long, title: String, reason: String, details: String) {
        viewModelScope.launch {
            repository.reportContent(contentId, title, reason, details)
            closeReportDialog()
            showSnackbar("রিপোর্ট গ্রহণ করা হয়েছে। ইসলামিক তাহকীক বোর্ড যাচাই করবে।")
        }
    }

    fun uploadContent(
        title: String,
        arabicText: String?,
        description: String,
        type: ContentType,
        category: String,
        sourceReference: String,
        authorName: String,
        duration: String? = null
    ) {
        viewModelScope.launch {
            repository.uploadContent(
                title = title,
                arabicText = arabicText,
                description = description,
                type = type,
                category = category,
                sourceReference = sourceReference,
                authorName = authorName,
                duration = duration
            )
            _uiState.value = _uiState.value.copy(
                uploadSuccessMessage = "আপনার কন্টেন্ট পর্যালোচনার জন্য জমা দেওয়া হয়েছে। তাহকীক বোর্ডের অনুমোদনের পর তা সবার কাছে পৌঁছাবে ইনশাআল্লাহ।"
            )
        }
    }

    fun clearUploadSuccessMessage() {
        _uiState.value = _uiState.value.copy(uploadSuccessMessage = null)
    }

    fun moderateContent(id: Long, status: ModerationStatus, notes: String?) {
        viewModelScope.launch {
            repository.moderateItem(id, status, notes)
            showSnackbar(if (status == ModerationStatus.APPROVED) "কন্টেন্ট অনুমোদিত হয়েছে ও লাইভ করা হয়েছে!" else "কন্টেন্ট প্রত্যাখ্যাত হয়েছে।")
        }
    }

    fun toggleMonetizationHub(show: Boolean) {
        _uiState.value = _uiState.value.copy(showMonetizationHub = show)
    }

    fun toggleModerationHub(show: Boolean) {
        _uiState.value = _uiState.value.copy(showModerationHub = show)
    }

    fun dismissSplash() {
        _uiState.value = _uiState.value.copy(isSplashVisible = false)
    }

    fun showSplash() {
        _uiState.value = _uiState.value.copy(isSplashVisible = true)
    }

    fun openAuth(initialTab: Int = 0) {
        _uiState.value = _uiState.value.copy(showAuthDialog = true, authInitialTab = initialTab)
    }

    fun closeAuth() {
        _uiState.value = _uiState.value.copy(showAuthDialog = false)
    }

    fun openDownloadSection() {
        _uiState.value = _uiState.value.copy(showDownloadSection = true)
    }

    fun closeDownloadSection() {
        _uiState.value = _uiState.value.copy(showDownloadSection = false)
    }

    fun onAuthSuccess(userName: String, isNewRegistration: Boolean) {
        _uiState.value = _uiState.value.copy(
            isLoggedIn = true,
            loggedInUserName = userName,
            showAuthDialog = false,
            snackbarMessage = if (isNewRegistration) "মাশাআল্লাহ! স্বাগতম দ্বীন মিডিয়াতে, $userName ভাই" else "সফলভাবে লগইন হয়েছে। আসসালামু আলাইকুম, $userName"
        )
    }

    fun logout() {
        _uiState.value = _uiState.value.copy(
            isLoggedIn = false,
            loggedInUserName = "অতিথি ব্যবহারকারী",
            snackbarMessage = "আপনি লগআউট হয়েছেন।"
        )
    }

    fun showSnackbar(message: String) {
        _uiState.value = _uiState.value.copy(snackbarMessage = message)
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }
}
