package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ContentItem
import com.example.ui.theme.AlertRed

@Composable
fun ReportDialog(
    item: ContentItem,
    onDismiss: () -> Unit,
    onSubmitReport: (contentId: Long, title: String, reason: String, details: String) -> Unit
) {
    val reportReasons = listOf(
        "ভুল হাদিস বা অপ্রামাণ্য/জাল বর্ণনা",
        "ভুল বা বিভ্রান্তিকর ধর্মীয় তথ্য",
        "কপিরাইট লঙ্ঘন",
        "বিদ্বেষমূলক বা অনুপযুক্ত বক্তব্য",
        "অন্যান্য সমস্যা"
    )

    var selectedReason by remember { mutableStateOf(reportReasons[0]) }
    var details by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.ReportProblem,
                contentDescription = "Report content",
                tint = AlertRed
            )
        },
        title = {
            Text(
                text = "ভুল বা আপত্তিকর তথ্য রিপোর্ট করুন",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "নূর মিডিয়া সম্পূর্ণ নির্ভরযোগ্য ও কুরআন-সুন্নাহ সম্মত কন্টেন্ট নিশ্চিত করতে অঙ্গীকারবদ্ধ। কোনো অসঙ্গতি চোখে পড়লে অনুগ্রহ করে জানান।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "কন্টেন্ট: \"${item.title.take(45)}...\"",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "সমস্যার কারণ নির্বাচন করুন:",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                )

                reportReasons.forEach { reason ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedReason = reason }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (selectedReason == reason),
                            onClick = { selectedReason = reason },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = AlertRed
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = reason,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("অতিরিক্ত বিবরণ বা রেফারেন্স (ঐচ্ছিক)") },
                    placeholder = { Text("যেমন: সহীহ বর্ণনাটির মূল সূত্র...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_details_field"),
                    minLines = 2,
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmitReport(item.id, item.title, selectedReason, details)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = AlertRed
                ),
                modifier = Modifier.testTag("submit_report_button")
            ) {
                Text("রিপোর্ট জমা দিন")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_report_button")
            ) {
                Text("বাতিল")
            }
        }
    )
}
