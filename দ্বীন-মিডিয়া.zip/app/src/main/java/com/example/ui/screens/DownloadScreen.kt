package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Modern Islamic App Download Section for "দ্বীন মিডিয়া" (Deen Media).
 * Features:
 * - Deep Emerald Green and Gold Islamic theme
 * - Prominent "দ্বীন মিডিয়া" Logo with glowing aura
 * - Rich background with arabesque / Islamic subtle gradient styling
 * - App tagline: “দ্বীনের আলো ছড়াক সবার মাঝে”
 * - App brief intro: “ইসলামী ভিডিও, ছবি ও উপকারী কনটেন্টের একটি সুন্দর প্ল্যাটফর্ম।”
 * - Eye-catching "📲 অ্যাপ ডাউনলোড করুন" button
 * - Subtitle: “Android-এর জন্য ডাউনলোড করুন”
 * - Note: “দ্বীনের সুন্দর বার্তা ছড়িয়ে দিন এবং উপকারী কনটেন্টের সাথে যুক্ত থাকুন।”
 * - Fast, mobile-friendly, responsive layout with APK file info, verified safe badge, and share flow.
 */
@Composable
fun DownloadScreen(
    onClose: () -> Unit,
    apkDownloadUrl: String = "https://ais-pre-oh5gj35ctloxmeiorz2b6d-70258313462.asia-east1.run.app/DeenMedia-v1.0.apk"
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var isDownloading by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableFloatStateOf(0f) }
    var isDownloadComplete by remember { mutableStateOf(false) }

    // Pulsing subtle glow for the download button
    val pulseAnim = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        pulseAnim.animateTo(
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF032214), // Deep rich Islamic emerald
            Color(0xFF073822),
            Color(0xFF02160C)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundGradient)
            .testTag("app_download_section")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
                .padding(top = 16.dp, bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar with Back Button & Share icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .testTag("download_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "ফিরে যান",
                        tint = Color.White
                    )
                }

                Surface(
                    color = GoldAccent.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent.copy(alpha = 0.6f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "১০০% নিরাপদ ও হালাল",
                            color = GoldAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "দ্বীন মিডিয়া — দ্বীনের আলো ছড়াক সবার মাঝে। ইসলামী ভিডিও, ছবি ও উপকারী কনটেন্টের নিরাপদ প্ল্যাটফর্ম। এখনই ডাউনলোড করুন:\n$apkDownloadUrl"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "দ্বীন মিডিয়া অ্যাপ শেয়ার করুন"))
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .testTag("download_share_top_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "শেয়ার করুন",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Islamic Header Motif
            Text(
                text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                color = GoldAccent.copy(alpha = 0.85f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // DEEN MEDIA LOGO CONTAINER
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(136.dp)
            ) {
                // Radiant golden glow backdrop
                Box(
                    modifier = Modifier
                        .size(132.dp)
                        .clip(CircleShape)
                        .background(GoldAccent.copy(alpha = 0.22f))
                )

                // Logo Card Frame with gold border
                Card(
                    shape = RoundedCornerShape(32.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF042416)),
                    modifier = Modifier
                        .size(120.dp)
                        .border(
                            width = 2.5.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(GoldAccent, Color(0xFFE8C86A), Color(0xFF0D5C3A))
                            ),
                            shape = RoundedCornerShape(32.dp)
                        )
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_deen_media_logo),
                            contentDescription = "দ্বীন মিডিয়া লোগো",
                            modifier = Modifier
                                .size(120.dp)
                                .clip(RoundedCornerShape(32.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // App Name: দ্বীন মিডিয়া
            Text(
                text = "দ্বীন মিডিয়া",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Tagline: “দ্বীনের আলো ছড়াক সবার মাঝে”
            Text(
                text = "“দ্বীনের আলো ছড়াক সবার মাঝে”",
                color = GoldAccent,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // App Brief Intro: “ইসলামী ভিডিও, ছবি ও উপকারী কনটেন্টের একটি সুন্দর প্ল্যাটফর্ম।”
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF093E26).copy(alpha = 0.85f)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF14603B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ইসলামী ভিডিও, ছবি ও উপকারী কনটেন্টের একটি সুন্দর প্ল্যাটফর্ম।",
                        color = Color.White.copy(alpha = 0.95f),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FeatureMiniBadge(icon = "🕌", label = "বিশুদ্ধ কনটেন্ট")
                        FeatureMiniBadge(icon = "🛡️", label = "বিজ্ঞাপনহীন")
                        FeatureMiniBadge(icon = "⚡", label = "দ্রুত ও নিরাপদ")
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // ==================== BIG EYE-CATCHING DOWNLOAD BUTTON ====================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(if (isDownloading) 1f else pulseAnim.value),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = {
                        if (!isDownloading) {
                            isDownloading = true
                            isDownloadComplete = false
                            downloadProgress = 0f

                            // Launch download logic with simulated progress & open browser/APK download
                            coroutineScope.launch {
                                for (i in 1..10) {
                                    delay(200)
                                    downloadProgress = i / 10f
                                }
                                isDownloading = false
                                isDownloadComplete = true
                                Toast.makeText(
                                    context,
                                    "দ্বীন মিডিয়া APK সফলভাবে ডাউনলোড হয়েছে!",
                                    Toast.LENGTH_LONG
                                ).show()

                                // Open download URL in browser or package installer
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(apkDownloadUrl))
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // Fallback
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .shadow(
                            elevation = 12.dp,
                            shape = RoundedCornerShape(20.dp),
                            spotColor = GoldAccent,
                            ambientColor = GoldAccent
                        )
                        .testTag("download_apk_button"),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFD4AF37), // Metallic Gold
                                        Color(0xFFF3D578),
                                        Color(0xFFE5B93E)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (isDownloading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(26.dp),
                                    color = Color(0xFF042416),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "ডাউনলোড হচ্ছে ${(downloadProgress * 100).toInt()}%...",
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF042416)
                                )
                            } else if (isDownloadComplete) {
                                Icon(
                                    imageVector = Icons.Default.DownloadDone,
                                    contentDescription = null,
                                    tint = Color(0xFF042416),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "ডাউনলোড সম্পন্ন! ইনস্টল করুন",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF042416)
                                )
                            } else {
                                Text(
                                    text = "📲 অ্যাপ ডাউনলোড করুন",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF042416),
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }
            }

            // Download Progress Bar if in progress
            if (isDownloading) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { downloadProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = GoldAccent,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Text under download button: “Android-এর জন্য ডাউনলোড করুন”
            Text(
                text = "Android-এর জন্য ডাউনলোড করুন",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtext: “দ্বীনের সুন্দর বার্তা ছড়িয়ে দিন এবং উপকারী কনটেন্টের সাথে যুক্ত থাকুন।”
            Text(
                text = "“দ্বীনের সুন্দর বার্তা ছড়িয়ে দিন এবং উপকারী কনটেন্টের সাথে যুক্ত থাকুন।”",
                color = GoldAccent.copy(alpha = 0.9f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                lineHeight = 19.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // APK SPECIFICATION DETAILS CARD
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF062D1C)),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0F5A38)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = "অ্যাপ্লিকেশন বিবরণ ও বৈশিষ্ট্য",
                        color = GoldAccent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ApkSpecRow(label = "অ্যাপের নাম:", value = "দ্বীন মিডিয়া (Deen Media)")
                    ApkSpecRow(label = "ভার্সন:", value = "v1.2.0 (সর্বশেষ আপডেট)")
                    ApkSpecRow(label = "ফাইল সাইজ:", value = "১৮.৫ মেগাবাইট (Lightweight)")
                    ApkSpecRow(label = "প্রয়োজনীয় ওএস:", value = "Android 8.0 ও তদূর্ধ্ব")
                    ApkSpecRow(label = "নিরাপত্তা স্ট্যাটাস:", value = "Play Protect ও তাহকীককৃত")

                    HorizontalDivider(
                        color = Color.White.copy(alpha = 0.1f),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    // Secondary Action Buttons: Copy Link & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Deen Media APK Link", apkDownloadUrl)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "ডাউনলোড লিঙ্ক কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("download_copy_link_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "লিঙ্ক কপি",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "আসসালামু আলাইকুম! দ্বীন মিডিয়া অ্যাপ ডাউনলোড করে খাঁটি দ্বীনি কনটেন্ট ও কুরআন-হাদিসের সাথে থাকুন:\n$apkDownloadUrl"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "শেয়ার করুন"))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("download_share_app_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "শেয়ার করুন",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Footer note
            Text(
                text = "দ্বীন মিডিয়া © ২০২৬ • দ্বীন ও মানবতার কল্যাণে নিবেদিত",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun FeatureMiniBadge(
    icon: String,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(text = icon, fontSize = 14.sp)
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun ApkSpecRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 13.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
