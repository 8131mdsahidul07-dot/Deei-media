package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.OnGoldContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonetizationScreen(
    onBack: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "প্ল্যাটফর্ম ইনকাম ও হালাল মডেল",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EmeraldPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.testTag("monetization_screen")
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Intro summary
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = OnEmeraldContainer,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "শরীয়াহসম্মত টেকসই আয় কাঠামো",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = OnEmeraldContainer
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "একটি ইসলামিক প্ল্যাটফর্ম পরিচালনার জন্য সার্ভার খরচ, তাহকীক বোর্ডের হাদিস গবেষকদের সম্মাননা এবং প্রযুক্তিগত উন্নয়নের জন্য হালাল আয়ের উৎস অপরিহার্য। নিচে নূর মিডিয়ার ৫টি প্রধান আয় মডেল তুলে ধরা হলো:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = OnEmeraldContainer.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            // Model 1: Halal Ads
            item {
                IncomeModelCard(
                    icon = Icons.Default.MonetizationOn,
                    badgeText = "মডেল ১",
                    title = "নিয়ন্ত্রিত হালাল বিজ্ঞাপন (Halal Ads)",
                    description = "সাধারণ অ্যাপের মতো গান-বাজনা, নারী-পুরুষের অশালীন ছবি বা সুদী ব্যাংকিংয়ের বিজ্ঞাপন নূর মিডিয়ায় সম্পূর্ণ নিষিদ্ধ।",
                    bulletPoints = listOf(
                        "হালাল ইসলামিক প্রকাশনী ও বইয়ের বিজ্ঞাপন",
                        "মাদরাসা ও দাতব্য শিক্ষা প্রতিষ্ঠানের প্রচার",
                        "হালাল খাদ্যপণ্য, আতর, জায়নামাজ ও ফ্যাশন ব্র্যান্ড",
                        "ফিল্টার্ড ফ্যামিলি-ফ্রেন্ডলি বিজ্ঞাপন নেটওয়ার্ক"
                    ),
                    actionText = "বিজ্ঞাপন নীতিমালা দেখুন",
                    onAction = { onShowMessage("হালাল অ্যাড পলিসি সক্রিয়: অশালীন ও সুদভিত্তিক বিজ্ঞাপন স্বয়ংক্রিয়ভাবে ব্লক করা হয়।") }
                )
            }

            // Model 2: Premium Subscription
            item {
                IncomeModelCard(
                    icon = Icons.Default.Star,
                    badgeText = "মডেল ২ (সেরা)",
                    title = "Noor Premium সাবস্ক্রিপশন ⭐",
                    description = "ব্যবহারকারীরা স্বল্প মাসিক ফিয়ে প্রিমিয়াম ইসলামিক ফিচার উপভোগ করতে পারেন।",
                    bulletPoints = listOf(
                        "সম্পূর্ণ বিজ্ঞাপনমুক্ত আত্মশুদ্ধির পরিবেশ",
                        "অফলাইনে উচ্চমানের ভিডিও ও তিলাওয়াত ডাউনলোড",
                        "বিশেষ ইসলামিক কোর্স (তাজবীদ শিক্ষা, আরবি ভাষা, সিরাত)",
                        "লাইভ প্রশ্নোত্তর সেশনে আলেমদের সাথে সরাসরি যুক্ত হওয়া"
                    ),
                    actionText = "প্রিমিয়াম প্ল্যান দেখুন (৳৯৯ / মাস)",
                    onAction = { onShowMessage("নূর প্রিমিয়াম ট্রায়াল শিগগিরই উন্মুক্ত হবে ইনশাআল্লাহ।") },
                    isHighlighted = true
                )
            }

            // Model 3: Creator Monetization
            item {
                IncomeModelCard(
                    icon = Icons.Default.School,
                    badgeText = "মডেল ৩",
                    title = "ক্রিয়েটর হাদিয়া ও রেভিনিউ শেয়ারিং",
                    description = "যোগ্য আলেম, গবেষক ও কন্টেন্ট নির্মাতাদের উৎসাহ দিতে তাদের জন্য সম্মানী ব্যবস্থা।",
                    bulletPoints = listOf(
                        "ভিডিওর ভিউ ও প্রশংসার ভিত্তিতে ক্রিয়েটর হাদিয়া ফান্ড",
                        "শ্রোতা-দর্শকদের সরাসরি 'হাদিয়া/সাপোর্ট' পাঠানোর সুযোগ",
                        "প্ল্যাটফর্ম পরিচালন খরচের জন্য ১০% প্রশাসনিক ফি সংরক্ষণ",
                        "ভেরিফায়েড ইসলামিক চ্যানেল পার্টনারশিপ প্রোগ্রাম"
                    ),
                    actionText = "ক্রিয়েটর গাইডলাইন পড়ুন",
                    onAction = { onShowMessage("ক্রিয়েটর মনিটাইজেশন পলিসি পর্যালোচনাধীন।") }
                )
            }

            // Model 4: Islamic Business Sponsorship
            item {
                IncomeModelCard(
                    icon = Icons.Default.BusinessCenter,
                    badgeText = "মডেল ৪",
                    title = "ইসলামিক বিজনেস স্পনসরশিপ",
                    description = "বিশ্বস্ত হালাল উদ্যোগ ও ইসলামি ব্যাংকগুলোর সাথে দীর্ঘমেয়াদী ব্র্যান্ডিং পার্টনারশিপ।",
                    bulletPoints = listOf(
                        "রমজান ও ঈদুল ফিতর/আযহার বিশেষ স্পনসরশিপ প্যাকেজ",
                        "কুরআন তিলাওয়াত প্রতিযোগিতার প্রাতিষ্ঠানিক স্পনসর",
                        "হালাল ট্রাভেল ও উমরাহ এজেন্সির অনুমোদিত পার্টনার ডিরেক্টরি",
                        "হোমস্ক্রিন স্পনসর ব্যানার"
                    ),
                    actionText = "স্পনসরশিপ যোগাযোগ",
                    onAction = { onShowMessage("স্পনসরশিপ ইমেইল: sponsor@noormedia.org") }
                )
            }

            // Model 5: Donation / Sadaqah Jariyah
            item {
                IncomeModelCard(
                    icon = Icons.Default.VolunteerActivism,
                    badgeText = "মডেল ৫",
                    title = "সাদাকায়ে জারিয়া ও ডোনেশন সাপোর্ট 🤲",
                    description = "দ্বীনের প্রসারে ব্যবহারকারীদের স্বেচ্ছায় দান করার সুযোগ। সম্পূর্ণ শতভাগ স্বচ্ছ আর্থিক বিবরণী প্রকাশ।",
                    bulletPoints = listOf(
                        "সার্ভার ও ক্লাউড স্টোরেজ খরচে সহযোগিতা",
                        "বিনামূল্যে সাধারণ মানুষের কাছে বিশুদ্ধ সহীহ হাদিস পৌঁছানো",
                        "তাহকীক বোর্ডের মুহাদ্দিসদের সার্বক্ষণিক নিরীক্ষা ফান্ড",
                        "অ্যাপের অর্থায়নের মাসিক উন্মুক্ত ব্যয় রিপোর্ট"
                    ),
                    actionText = "সাদাকায়ে জারিয়ায় অংশ নিন",
                    onAction = { onShowMessage("আপনার সাদাকা দ্বীনের প্রসারে সহায়ক হোক। জাযাকাল্লাহু খাইরান।") }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun IncomeModelCard(
    icon: ImageVector,
    badgeText: String,
    title: String,
    description: String,
    bulletPoints: List<String>,
    actionText: String,
    onAction: () -> Unit,
    isHighlighted: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlighted) GoldContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isHighlighted) 4.dp else 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isHighlighted) GoldAccent else EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Surface(
                        color = if (isHighlighted) GoldContainer else EmeraldContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = badgeText,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isHighlighted) OnGoldContainer else OnEmeraldContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            bulletPoints.forEach { point ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = point,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onAction,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isHighlighted) GoldAccent else EmeraldPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = actionText)
            }
        }
    }
}
