package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ContentItem
import com.example.data.ContentType
import com.example.ui.components.PostCard
import com.example.ui.theme.EmeraldPrimary

@Composable
fun PostsScreen(
    posts: List<ContentItem>,
    onToggleLike: (ContentItem) -> Unit,
    onToggleBookmark: (ContentItem) -> Unit,
    onOpenReport: (ContentItem) -> Unit,
    onCopySuccess: (String) -> Unit
) {
    val postTypes = listOf("সব পোস্ট", "কুরআন আয়াত", "সহীহ হাদিস", "প্রয়োজনীয় দোয়া", "ইসলামিক উক্তি")
    var selectedType by remember { mutableStateOf("সব পোস্ট") }

    val filteredPosts = when (selectedType) {
        "কুরআন আয়াত" -> posts.filter { it.type == ContentType.AYAT }
        "সহীহ হাদিস" -> posts.filter { it.type == ContentType.HADITH }
        "প্রয়োজনীয় দোয়া" -> posts.filter { it.type == ContentType.DUA }
        "ইসলামিক উক্তি" -> posts.filter { it.type == ContentType.QUOTE }
        else -> posts
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("posts_screen_list"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = EmeraldPrimary
                    )
                    Text(
                        text = "আয়াত, হাদিস ও ইসলামিক পোস্ট",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = "প্রামাণ্য সূত্রসহ কুরআনের আয়াত, সহীহ হাদিস, মাসনূন দোয়া ও মনীষীদের বাণী",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Filter Chips
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(postTypes) { typeLabel ->
                    val isSelected = (selectedType == typeLabel)
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedType = typeLabel },
                        label = { Text(typeLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("post_filter_$typeLabel")
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Post cards
        items(filteredPosts, key = { it.id }) { postItem ->
            PostCard(
                item = postItem,
                onToggleLike = onToggleLike,
                onToggleBookmark = onToggleBookmark,
                onOpenReport = onOpenReport,
                onCopySuccess = onCopySuccess
            )
        }
    }
}
