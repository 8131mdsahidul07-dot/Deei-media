package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ContentItem
import com.example.data.ModerationStatus
import com.example.data.ReportItem
import com.example.ui.components.PostCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ApprovedGreen
import com.example.ui.theme.ApprovedGreenContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.OnGoldContainer
import com.example.ui.theme.PendingAmber
import com.example.ui.theme.PendingAmberContainer

@Composable
fun ProfileScreen(
    userUploads: List<ContentItem>,
    pendingReviews: List<ContentItem>,
    bookmarkedItems: List<ContentItem>,
    reports: List<ReportItem>,
    isLoggedIn: Boolean = true,
    userName: String = "মুহাম্মাদ আবদুল্লাহ",
    onOpenAuth: (Int) -> Unit = {},
    onLogout: () -> Unit = {},
    onViewSplash: () -> Unit = {},
    onModerateItem: (Long, ModerationStatus, String?) -> Unit,
    onOpenMonetizationHub: () -> Unit,
    onToggleLike: (ContentItem) -> Unit,
    onToggleBookmark: (ContentItem) -> Unit,
    onOpenReport: (ContentItem) -> Unit,
    onCopySuccess: (String) -> Unit,
    onOpenDownloadSection: () -> Unit = {}
) {
    var selectedProfileTab by remember { mutableIntStateOf(0) }

    val tabs = listOf("আমার আপলোড", "সংরক্ষিত কন্টেন্ট", "তাহকীক ও মডারেশন")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Profile Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(44.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isLoggedIn) userName else "অতিথি ব্যবহারকারী",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        if (isLoggedIn) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified Creator",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Text(
                        text = if (isLoggedIn) "দ্বীন মিডিয়া ভেরিফাইড ক্রিয়েটর ও দাঈ" else "লগইন করে আপনার নিজস্ব কনটেন্ট প্রকাশ করুন",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Auth action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isLoggedIn) {
                            OutlinedButton(
                                onClick = onLogout,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("profile_logout_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Logout,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("লগআউট", fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = { onOpenAuth(0) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("profile_switch_account_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("অ্যাকাউন্ট বদলান", fontSize = 13.sp)
                            }
                        } else {
                            Button(
                                onClick = { onOpenAuth(0) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("profile_login_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Login,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("লগইন করুন", fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = { onOpenAuth(1) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("profile_register_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("নতুন একাউন্ট", fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Stats row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ProfileStatItem(number = "${userUploads.size}", label = "আপলোড")
                        ProfileStatItem(
                            number = "${userUploads.count { it.moderationStatus == ModerationStatus.APPROVED }}",
                            label = "অনুমোদিত"
                        )
                        ProfileStatItem(
                            number = "${userUploads.count { it.moderationStatus == ModerationStatus.PENDING_REVIEW }}",
                            label = "পর্যালোচনাধীন"
                        )
                        ProfileStatItem(number = "${bookmarkedItems.size}", label = "সংরক্ষিত")
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Halal Monetization Button
                    Button(
                        onClick = onOpenMonetizationHub,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_monetization_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "প্ল্যাটফর্ম ইনকাম ও হালাল মডেল (বিজ্ঞাপন, প্রিমিয়াম, দান)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Deen Media Brand & Splash Showcase Item
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(EmeraldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_deen_media_logo),
                                contentDescription = "দ্বীন মিডিয়া লোগো",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Column {
                            Text(
                                text = "দ্বীন মিডিয়া (Deen Media)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = EmeraldPrimary
                            )
                            Text(
                                text = "দ্বীনের আলো ছড়াক সবার মাঝে",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onViewSplash,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("profile_view_splash_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("স্প্ল্যাশ দেখুন", fontSize = 12.sp)
                    }
                }
            }
        }

        // Deen Media App Download Card
        item {
            Card(
                onClick = onOpenDownloadSection,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("profile_download_app_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF042416)),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(GoldAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "📲 অ্যাপ ডাউনলোড করুন",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = "Android APK ডাউনলোড ও শেয়ার করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = GoldAccent
                            )
                        }
                    }

                    Button(
                        onClick = onOpenDownloadSection,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("profile_download_apk_button")
                    ) {
                        Text(
                            text = "APK পান",
                            color = Color(0xFF042416),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Tab Navigation
        item {
            TabRow(
                selectedTabIndex = selectedProfileTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EmeraldPrimary,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = (selectedProfileTab == index),
                        onClick = { selectedProfileTab = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (selectedProfileTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        modifier = Modifier.testTag("profile_tab_$index")
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Tab 0: My Uploads
        if (selectedProfileTab == 0) {
            if (userUploads.isEmpty()) {
                item {
                    EmptySection(
                        title = "এখনও কোনো কন্টেন্ট আপলোড করেননি",
                        subtitle = "নিচের ➕ আপলোড বাটন থেকে আপনার প্রথম ইসলামিক কন্টেন্টটি শেয়ার করুন।"
                    )
                }
            } else {
                items(userUploads, key = { it.id }) { item ->
                    UserUploadItemCard(item = item)
                }
            }
        }

        // Tab 1: Bookmarks
        if (selectedProfileTab == 1) {
            if (bookmarkedItems.isEmpty()) {
                item {
                    EmptySection(
                        title = "কোনো সংরক্ষিত কন্টেন্ট নেই",
                        subtitle = "পছন্দের আয়াত, হাদিস বা ভিডিও বুকমার্ক করে এখানে সহজেই খুঁজে নিন।"
                    )
                }
            } else {
                items(bookmarkedItems, key = { it.id }) { item ->
                    PostCard(
                        item = item,
                        onToggleLike = onToggleLike,
                        onToggleBookmark = onToggleBookmark,
                        onOpenReport = onOpenReport,
                        onCopySuccess = onCopySuccess
                    )
                }
            }
        }

        // Tab 2: Tahqeeq & Moderation Review Board (Admin Panel)
        if (selectedProfileTab == 2) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "তাহকীক ও কন্টেন্ট মডারেশন বোর্ড",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "ভুল হাদিস ও জাল বর্ণনা ঠেকানোর সার্বক্ষণিক ফিল্টারিং সিস্টেম। এখানে পর্যালোচনায় থাকা কন্টেন্ট যাচাই করে অনুমোদন দেওয়া হয়।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Pending Submissions
            item {
                Text(
                    text = "পর্যালোচনার জন্য অপেক্ষমান কন্টেন্ট (${pendingReviews.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            if (pendingReviews.isEmpty()) {
                item {
                    EmptySection(
                        title = "কোনো কন্টেন্ট পর্যালোচনার অপেক্ষায় নেই",
                        subtitle = "সব আপলোডকৃত কন্টেন্ট যাচাই সম্পন্ন হয়েছে।"
                    )
                }
            } else {
                items(pendingReviews, key = { it.id }) { pendingItem ->
                    ModerationReviewCard(
                        item = pendingItem,
                        onApprove = {
                            onModerateItem(pendingItem.id, ModerationStatus.APPROVED, "তাহকীক বোর্ড কর্তৃক অনুমোদিত")
                        },
                        onReject = {
                            onModerateItem(pendingItem.id, ModerationStatus.REJECTED, "সঠিক রেফারেন্সের অভাব বা অপ্রামাণ্য তথ্য")
                        }
                    )
                }
            }

            // Reported Items Section
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "ব্যবহারকারীদের রিপোর্টসমূহ (${reports.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            if (reports.isEmpty()) {
                item {
                    EmptySection(
                        title = "কোনো রিপোর্ট জমা পড়েনি",
                        subtitle = "ব্যবহারকারীরা কোনো ভুল বা আপত্তিকর তথ্য চিহ্নিত করেননি।"
                    )
                }
            } else {
                items(reports, key = { it.id }) { report ->
                    ReportItemCard(report = report)
                }
            }
        }
    }
}

@Composable
fun ProfileStatItem(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = number,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun UserUploadItemCard(item: ContentItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = item.category,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                // Status Badge
                when (item.moderationStatus) {
                    ModerationStatus.APPROVED -> {
                        Surface(
                            color = ApprovedGreenContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "অনুমোদিত (লাইভ)",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = ApprovedGreen
                            )
                        }
                    }
                    ModerationStatus.PENDING_REVIEW -> {
                        Surface(
                            color = PendingAmberContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "পর্যালোচনাধীন",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = PendingAmber
                            )
                        }
                    }
                    ModerationStatus.REJECTED -> {
                        Surface(
                            color = Color(0xFFFFDAD6),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "প্রত্যাখ্যাত",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = AlertRed
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "রেফারেন্স: ${item.sourceReference}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (item.moderationNotes != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "বোর্ডের মন্তব্য: ${item.moderationNotes}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = EmeraldPrimary
                )
            }
        }
    }
}

@Composable
fun ModerationReviewCard(
    item: ContentItem,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    color = PendingAmberContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "নতুন কন্টেন্ট রিভিউ",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = PendingAmber
                    )
                }

                Text(
                    text = "লেখক: ${item.authorName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            if (!item.arabicText.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.arabicText,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = EmeraldPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "সূত্র/রেফারেন্স: ${item.sourceReference}",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(8.dp),
                    color = EmeraldPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = ApprovedGreen),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("অনুমোদন দিন")
                }

                OutlinedButton(
                    onClick = onReject,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("বাতিল করুন")
                }
            }
        }
    }
}

@Composable
fun ReportItemCard(report: ReportItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ReportProblem,
                        contentDescription = null,
                        tint = AlertRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = report.reason,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = AlertRed
                    )
                }

                Surface(
                    color = PendingAmberContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = report.status,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = PendingAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "কন্টেন্ট: \"${report.contentTitle}\"",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
            )

            if (report.details.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "বিবরণ: ${report.details}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmptySection(title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }
    }
}
