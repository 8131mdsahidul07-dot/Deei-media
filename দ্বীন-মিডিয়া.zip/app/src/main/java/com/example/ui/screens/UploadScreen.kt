package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ContentType
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.OnGoldContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(
    onUploadSubmitted: (
        title: String,
        arabicText: String?,
        description: String,
        type: ContentType,
        category: String,
        sourceReference: String,
        authorName: String,
        duration: String?
    ) -> Unit,
    uploadSuccessMessage: String?,
    onDismissSuccess: () -> Unit
) {
    val categories = listOf("কুরআন", "হাদিস", "দোয়া", "ওয়াজ", "তিলাওয়াত", "শিশুদের ইসলাম", "ইসলামিক ইতিহাস")
    val contentTypes = listOf("ভিডিও (Video)", "কুরআন আয়াত (Ayat)", "হাদিস শিক্ষা (Hadith)", "মাসনূন দোয়া (Dua)", "ইসলামিক উক্তি/পোস্ট (Post)")

    var selectedTypeIndex by remember { mutableStateOf(0) }
    var title by remember { mutableStateOf("") }
    var arabicText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var sourceReference by remember { mutableStateOf("") }
    var authorName by remember { mutableStateOf("") }
    var videoDuration by remember { mutableStateOf("08:30") }
    var videoLink by remember { mutableStateOf("") }
    var isConfirmedHalal by remember { mutableStateOf(false) }

    var categoryExpanded by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf(categories[0]) }

    var typeExpanded by remember { mutableStateOf(false) }

    var validationError by remember { mutableStateOf<String?>(null) }

    if (uploadSuccessMessage != null) {
        AlertDialog(
            onDismissRequest = onDismissSuccess,
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "কন্টেন্ট পর্যালোচনার জন্য জমা হয়েছে",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(text = uploadSuccessMessage)
            },
            confirmButton = {
                Button(
                    onClick = onDismissSuccess,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("ঠিক আছে")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("upload_screen"),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Title Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(28.dp)
                )
                Column {
                    Text(
                        text = "ক্রিয়েটর আপলোড স্টুডিও",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "ইসলামিক ভিডিও, আয়াত, হাদিস ও দোয়া শেয়ার করুন",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Moderation Safety Rule Card (Critical user requirement)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GoldContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "নিরাপদ ইসলামিক মডারেশন নীতিমালা",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = OnGoldContainer
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ভুল হাদিস, জাল বর্ণনা, বিভ্রান্তিকর ধর্মীয় বক্তব্য ও কপিরাইট লঙ্ঘন রোধে প্রতিটি আপলোড ইসলামিক তাহকীক বোর্ড দ্বারা যাচাই করে লাইভ করা হবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Form Fields
        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Content Type Selector
                ExposedDropdownMenuBox(
                    expanded = typeExpanded,
                    onExpandedChange = { typeExpanded = !typeExpanded }
                ) {
                    OutlinedTextField(
                        value = contentTypes[selectedTypeIndex],
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("কন্টেন্টের ধরন") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("upload_type_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = typeExpanded,
                        onDismissRequest = { typeExpanded = false }
                    ) {
                        contentTypes.forEachIndexed { index, label ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    selectedTypeIndex = index
                                    typeExpanded = false
                                }
                            )
                        }
                    }
                }

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        validationError = null
                    },
                    label = { Text("শিরোনাম *") },
                    placeholder = { Text("যেমন: জীবনের কঠিন সময়ে সবর করার উপায়") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_title_input")
                )

                // Category Selector
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("ক্যাটাগরি *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("upload_category_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                // Source Reference (CRITICAL)
                OutlinedTextField(
                    value = sourceReference,
                    onValueChange = {
                        sourceReference = it
                        validationError = null
                    },
                    label = { Text("প্রামাণ্য ধর্মীয় রেফারেন্স / সূত্র * (বাধ্যতামূলক)") },
                    placeholder = { Text("যেমন: সহীহুল বুখারী, হাদিস নং ১ / সূরা আল-বাকারা: ২৮৬") },
                    supportingText = { Text("নির্ভরযোগ্য হাদিস গ্রন্থ বা কুরআনের সূরা ও আয়াত উল্লেখ করুন") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_source_reference_input")
                )

                // Arabic Text (optional)
                OutlinedTextField(
                    value = arabicText,
                    onValueChange = { arabicText = it },
                    label = { Text("আরবি পাঠ (ঐচ্ছিক)") },
                    placeholder = { Text("যেমন: إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_arabic_text_input")
                )

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = {
                        description = it
                        validationError = null
                    },
                    label = { Text("বিস্তারিত বিবরণ বা ভাবানুবাদ *") },
                    placeholder = { Text("কন্টেন্টের বিস্তারিত আলোচনা, ব্যাখ্যা বা উপকারিতা লিখুন...") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_description_input")
                )

                // If Video type, ask for video link / duration
                if (selectedTypeIndex == 0) {
                    OutlinedTextField(
                        value = videoLink,
                        onValueChange = { videoLink = it },
                        label = { Text("ভিডিও ফাইল বা স্ট্রিম লিংক") },
                        placeholder = { Text("https://...") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = videoDuration,
                        onValueChange = { videoDuration = it },
                        label = { Text("ভিডিওর দৈর্ঘ্য (যেমন: 12:30)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Creator / Author Name
                OutlinedTextField(
                    value = authorName,
                    onValueChange = { authorName = it },
                    label = { Text("আপনার নাম / চ্যানেলের নাম") },
                    placeholder = { Text("মোঃ সাহিদুল ইসলাম") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Halal Declaration Checkbox
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isConfirmedHalal,
                        onCheckedChange = { isConfirmedHalal = it },
                        colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "আমি নিশ্চিত করছি যে এই কনটেন্টে কোনো ভুল বা বিতর্কিত তথ্য নেই এবং এটি কুরআন-সুন্নাহর সঠিক বিধানসম্মত।",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                // Error Text
                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Submit Button
                Button(
                    onClick = {
                        if (title.isBlank()) {
                            validationError = "অনুগ্রহ করে কন্টেন্টের শিরোনাম লিখুন।"
                            return@Button
                        }
                        if (sourceReference.isBlank()) {
                            validationError = "ভুল তথ্য রোধে প্রামাণ্য ধর্মীয় রেফারেন্স দেওয়া আবশ্যক।"
                            return@Button
                        }
                        if (description.isBlank()) {
                            validationError = "অনুগ্রহ করে বিস্তারিত বিবরণ লিখুন।"
                            return@Button
                        }
                        if (!isConfirmedHalal) {
                            validationError = "কন্টেন্ট জমা দিতে নির্ভরযোগ্যতা ও হালাল ঘোষণার শর্ত পূরণ করুন।"
                            return@Button
                        }

                        val mappedType = when (selectedTypeIndex) {
                            0 -> ContentType.VIDEO
                            1 -> ContentType.AYAT
                            2 -> ContentType.HADITH
                            3 -> ContentType.DUA
                            else -> ContentType.QUOTE
                        }

                        onUploadSubmitted(
                            title.trim(),
                            arabicText.trim().takeIf { it.isNotBlank() },
                            description.trim(),
                            mappedType,
                            selectedCategory,
                            sourceReference.trim(),
                            authorName.trim(),
                            if (mappedType == ContentType.VIDEO) videoDuration.trim() else null
                        )

                        // Clear fields
                        title = ""
                        arabicText = ""
                        description = ""
                        sourceReference = ""
                        videoLink = ""
                        isConfirmedHalal = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_upload_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "মডারেশনের জন্য জমা দিন",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
