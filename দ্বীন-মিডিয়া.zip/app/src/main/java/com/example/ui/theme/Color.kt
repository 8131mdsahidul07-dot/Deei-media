package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald & Forest Palette
val EmeraldPrimary = Color(0xFF0D5C3A)
val EmeraldPrimaryVariant = Color(0xFF063E26)
val EmeraldLight = Color(0xFF1B8254)
val EmeraldContainer = Color(0xFFD3EEDF)
val OnEmeraldContainer = Color(0xFF023820)

// Gold & Ochre Accents
val GoldAccent = Color(0xFFC99700)
val GoldLight = Color(0xFFF9DC76)
val GoldContainer = Color(0xFFFFF2C2)
val OnGoldContainer = Color(0xFF423100)

// Background & Surface
val WarmIvoryBackground = Color(0xFFF8F9F5)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFEDF2EC)
val TextDarkPrimary = Color(0xFF19211D)
val TextDarkSecondary = Color(0xFF4D5B53)
val BorderSubtle = Color(0xFFDCE5DE)

// Dark Theme Palette
val DarkBackground = Color(0xFF0D1713)
val DarkSurface = Color(0xFF14231E)
val DarkSurfaceVariant = Color(0xFF1D322A)
val DarkPrimary = Color(0xFF4BD396)
val DarkPrimaryContainer = Color(0xFF0F4E33)
val DarkGold = Color(0xFFE5B83B)
val TextLightPrimary = Color(0xFFEDF3EE)
val TextLightSecondary = Color(0xFFA6B8AE)
val DarkBorder = Color(0xFF283F35)

// Status & Alerts
val AlertRed = Color(0xFFBA1A1A)
val AlertRedContainer = Color(0xFFFFDAD6)
val PendingAmber = Color(0xFFD97706)
val PendingAmberContainer = Color(0xFFFEF3C7)
val ApprovedGreen = Color(0xFF15803D)
val ApprovedGreenContainer = Color(0xFFDCFCE7)
